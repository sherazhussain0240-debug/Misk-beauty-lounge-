# Misk Beauty Lounge

A responsive women's beauty salon website with a pink, peach and orange theme.

## Features
- Seven beauty service categories
- Searchable service price list in PKR
- Appointment request form
- Gallery, FAQ and contact sections
- Responsive mobile navigation

## Files
- `index.html` — complete website (HTML, CSS and JavaScript)
- `assets/misk-logo.png` — Misk Beauty Lounge logo

## Deploy with GitHub Pages
1. Create a GitHub repository named `misk-beauty-lounge`.
2. Upload `index.html`, `README.md`, and the `assets` folder (including `misk-logo.png`) to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site.

## Before publishing
Update the sample prices and add the salon's real address, phone/WhatsApp number, opening hours and social links. The appointment form is currently a front-end demo and does not send or store bookings. Connect it to a booking service or backend to receive real appointments.
